package com.example.loginproject;

public class Products {
    private String category;
    private  String type;
    private  int price;
    private  int image;
    private  String brands;



    public Products(String category, String type, int price, int image,String brands) {
        this.category = category;
        this.type = type;
        this.price = price;
        this.image = image;
        this.brands = brands;

    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getBrands() {
        return brands;
    }

    public void setBrands(String brands) {
        this.brands = brands;
    }



    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }
}
