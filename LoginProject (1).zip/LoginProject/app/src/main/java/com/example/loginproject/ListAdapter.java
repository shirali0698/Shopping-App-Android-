package com.example.loginproject;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class ListAdapter extends BaseAdapter {
    private ArrayList<Products> productdata;
    private LayoutInflater layoutInflater;

    public ListAdapter(Context context, ArrayList<Products> countryData) {
        this.productdata = countryData;
        layoutInflater= LayoutInflater.from(context);

    }

    @Override
    public int getCount() {
        return productdata.size();
    }

    @Override
    public Object getItem(int i) {
        return productdata.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @SuppressLint("DefaultLocale")
    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        ViewHolder holder;
        if( view==null){

            view= layoutInflater.inflate(R.layout.list_row,null);
            holder=new ViewHolder();
            holder.Brand=view.findViewById(R.id.txtbrand);
            holder.Type=view.findViewById(R.id.txttype);
            holder.price=view.findViewById(R.id.txtprice);
            holder.img=view.findViewById(R.id.imgitem);
            view.setTag(holder);
        }
        else

            holder=(ViewHolder) view.getTag();
        holder.Brand.setText(productdata.get(i).getBrands());
        holder.Type.setText(String.valueOf(productdata.get(i).getType()));
        holder.price.setText(String.valueOf(productdata.get(i).getPrice()));
       holder.img.setImageResource(productdata.get(i).getImage());

        return view;
    }
    static class ViewHolder{
        private TextView Brand;
        private TextView Type;
        private TextView price;
       private ImageView img;
    }

    }

