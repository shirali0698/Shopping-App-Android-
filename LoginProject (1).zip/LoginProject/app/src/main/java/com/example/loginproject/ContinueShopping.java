package com.example.loginproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.Spinner;

import java.util.ArrayList;

public class ContinueShopping extends AppCompatActivity implements AdapterView.OnItemSelectedListener, AdapterView.OnItemClickListener {
    Spinner sp;
    ListView lv;
    ImageView img;
    ArrayList<Products> product = new ArrayList<Products>();
    String categories[]={"Watch","Bags","Sunglasses","Shoes","Clothing"};

    ArrayList <Products> selectedcategory=new ArrayList<Products>();//arraylist for spinner formation
    public static String selectedbrands;
    public static String selectedtype;
    public static int selectedprice;
    public static int selectedimage;
    public static String selectedcategoryname;

    public void fillData(){

        product.add(new Products("Watch","AppleSeries3 Men",79,R.drawable.apple3men,"Apple"));
        product.add(new Products("Watch","FossilSteel Men",69,R.drawable.fossilmensteel,"Fossil"));
        product.add(new Products("Watch","FossilSteel Women",89,R.drawable.fossilsteelwomen,"Fossil"));
        product.add(new Products("Watch","Rolexdrive Men",98,R.drawable.rolexdrivemen,"Rolex"));
        product.add(new Products("Watch","TitanEdge Men",139,R.drawable.titanedgemen,"Titan"));
        product.add(new Products("Watch","TitanRoseGold Women",140,R.drawable.titanrosewomen,"Titan"));
        product.add(new Products("Watch","AppleSeries3 Women",89,R.drawable.apple3women,"Apple"));
        product.add(new Products("Watch","AppleSeries4 Men",99,R.drawable.apple4men,"Apple"));
        product.add(new Products("Watch","FossilSmoke Men",90,R.drawable.fossilmensmoke,"Fossil"));
        product.add(new Products("Watch","FossilSmoke Women",120,R.drawable.fossilsmokewomen,"Fossil"));
        product.add(new Products("Watch","RolexGold Men",110,R.drawable.rolexgoldmen,"Rolex"));
        product.add(new Products("Watch","Rolexseiko Men",139,R.drawable.rolexseikomen,"Rolex"));
        product.add(new Products("Watch","Rolexsubmariner Men",120,R.drawable.rolexsubmarinermen,"Rolex"));
        product.add(new Products("Watch","TitanGold Women",130,R.drawable.titalgoldwomen,"Titan"));
        product.add(new Products("Watch","TitanCoronograph",110,R.drawable.titancoronographmen,"Titan"));
        product.add(new Products("Watch","AppleSeries4 Women",70,R.drawable.apple4women,"Apple"));
        product.add(new Products("Watch","AppleSeries5 Men",98,R.drawable.apple5men,"Apple"));
        product.add(new Products("Watch","AppleSeries5 Women",90,R.drawable.apple5women,"Apple"));
        product.add(new Products("Watch","FossilGen4 Men",59,R.drawable.fossilgen4women,"Fossil"));
        product.add(new Products("Watch","FossilGen4 Women",99,R.drawable.fossilgen4men,"Fossil"));
        product.add(new Products("Watch","RolexPink Women",110,R.drawable.rolexpinkwomen,"Rolex"));
        product.add(new Products("Watch","RolexGold Women",119,R.drawable.rolexgoldwomen,"Rolex"));
        product.add(new Products("Watch","RolexDiamond Women",99,R.drawable.rolexdiamondwomen,"Rolex"));
        product.add(new Products("Watch","TitanWristWatch Women",120,R.drawable.titanwristmen,"Titan"));
        product.add(new Products("Watch","TitanWristWatch Women",110,R.drawable.titanwristwomen,"Titan"));
        product.add(new Products("Clothing","Jacket Men",69,R.drawable.levisjacket,"Levis"));
        product.add(new Products("Clothing","Denim Shirt Men",69,R.drawable.denim,"Levis"));
        product.add(new Products("Clothing","Denim Jeans",50,R.drawable.tommy1,"Toommy Hilfiger"));
        product.add(new Products("Clothing","T-Shirt",20,R.drawable.burberrymen6,"Burberry "));
        product.add(new Products("Clothing","Shirt",13,R.drawable.burberrymen4,"Burberry "));
        product.add(new Products("Clothing","Colouring Jeans",52,R.drawable.tommy4,"Toommy Hilfiger"));
        product.add(new Products("Clothing","Hoodies",43,R.drawable.tommy6,"Toommy Hilfiger"));
        product.add(new Products("Clothing","Shirt Men",43,R.drawable.levisshirts,"Levis"));
        product.add(new Products("Clothing","T-Shirt Men",19,R.drawable.levis,"Levis"));
        product.add(new Products("Clothing","Hoodie",22,R.drawable.burberrymen5,"Burberry "));
        product.add(new Products("Clothing","Jeans",30,R.drawable.burberrymen1,"Burberry "));
        product.add(new Products("Clothing","Winter Jacket",40,R.drawable.burberry4,"Burberry "));
        product.add(new Products("Clothing","Jeans Men",22,R.drawable.levijeans,"Levis"));
        product.add(new Products("Clothing","Rough Jeans",33,R.drawable.tommy2,"Toommy Hilfiger"));
        product.add(new Products("Clothing","Denim Shirt",19,R.drawable.tommy3,"Toommy Hilfiger"));
        product.add(new Products("Clothing","Jacket Women",45,R.drawable.levis4,"Levis"));
        product.add(new Products("Clothing","T-Shirt Women",43,R.drawable.levis3,"Levis"));
        product.add(new Products("Clothing","Jeans Women",23,R.drawable.levis2,"Levis"));
        product.add(new Products("Clothing","Denim Jacket",22,R.drawable.tommy7women,"Toommy Hilfiger"));
        product.add(new Products("Clothing","Shorts",23,R.drawable.tommy4women,"Toommy Hilfiger"));
        product.add(new Products("Clothing","Jeans",43,R.drawable.tommy1women,"Toommy Hilfiger"));
        product.add(new Products("Clothing","Denim Shirt Women",19,R.drawable.levis1,"Levis"));
        product.add(new Products("Clothing","Rough Jeans Women",54,R.drawable.levis5,"Levis"));
        product.add(new Products("Clothing","Denim Jacket",23,R.drawable.tommy5,"Toommy Hilfiger"));
        product.add(new Products("Clothing","One Piece",43,R.drawable.tommy9women,"Toommy Hilfiger"));
        product.add(new Products("Clothing","Hoodie",23,R.drawable.tommy6women,"Toommy Hilfiger"));
        product.add(new Products("Clothing","T-Shirt",19,R.drawable.tommy8women,"Toommy Hilfiger"));
        product.add(new Products("Clothing","Denim Jacket",35,R.drawable.burberry9,"Burberry "));
        product.add(new Products("Clothing","Dress",20,R.drawable.burberry1,"Burberry "));
        product.add(new Products("Bags","Backpack",75,R.drawable.skybag,"SkyBags "));
        product.add(new Products("Bags","Wallet",115,R.drawable.tommywallet,"Tommy Hillifiger "));
        product.add(new Products("Bags","Luggage Bag",90,R.drawable.skyluggage,"SkyBags "));
        product.add(new Products("Bags","BagPack",69,R.drawable.wildbag,"WildCraft "));
        product.add(new Products("Bags","Hand Bag",125,R.drawable.tommyhand,"Tommy Hillifiger "));
        product.add(new Products("Bags","BagPack",79,R.drawable.toomybag,"Tommy Hillifiger "));
        product.add(new Products("Bags","Trolley Bag",109,R.drawable.skytrolley,"SkyBags "));
        product.add(new Products("Bags","Wallet",60,R.drawable.wildwallet,"WildCraft "));
        product.add(new Products("Bags","Carry On  Bag",75,R.drawable.tommycarryon,"Tommy Hillifiger "));
        product.add(new Products("Bags","RuckSack",99,R.drawable.wildrucksack,"WildCraft "));
        product.add(new Products("Bags","Travel Bag",130,R.drawable.wildtravel,"WildCraft "));
        product.add(new Products("Sunglasses","Men Transperent",79,R.drawable.gum3,"GUCCI"));
        product.add(new Products("Sunglasses","Men Square",109,R.drawable.tom1,"Tom Ford"));
        product.add(new Products("Sunglasses","Women Cheeta Print",110,R.drawable.rayw1,"Rayban"));
        product.add(new Products("Sunglasses","Men Green",115,R.drawable.tom2,"Tom Ford"));
        product.add(new Products("Sunglasses","Women Black",120,R.drawable.rayw2,"Rayban"));
        product.add(new Products("Sunglasses","Women Square",79,R.drawable.guw1,"GUCCI"));
        product.add(new Products("Sunglasses","Women Round",110,R.drawable.guw2,"GUCCI"));
        product.add(new Products("Sunglasses","Men Round",90,R.drawable.tom3,"Tom Ford"));
        product.add(new Products("Sunglasses","Women Pink",99,R.drawable.rayw3,"Rayban"));
        product.add(new Products("Sunglasses","Men brown",110,R.drawable.gum2,"GUCCI"));
        product.add(new Products("Sunglasses","Women Pink",79,R.drawable.tomw2,"Tom Ford"));
        product.add(new Products("Sunglasses","Men Transperent",120,R.drawable.raym1,"Rayban"));
        product.add(new Products("Sunglasses","Women white",90,R.drawable.tomw3,"Tom Ford"));
        product.add(new Products("Sunglasses","Men Blue",98,R.drawable.raym2,"Rayban"));
        product.add(new Products("Sunglasses","Women Round",110,R.drawable.tomw1,"Tom Ford"));
        product.add(new Products("Sunglasses","Women Brown",90,R.drawable.guw3,"GUCCI"));
        product.add(new Products("Sunglasses","Men Round",109,R.drawable.gum1,"GUCCI"));
        product.add(new Products("Shoes","Women Original",80,R.drawable.aworig,"Addidas"));
        product.add(new Products("Shoes","Men Sneakers",70,R.drawable.pumasneakm,"PUMA"));
        product.add(new Products("Shoes","Women VolleyBall",79,R.drawable.awvolley,"Addidas"));
        product.add(new Products("Shoes","Men Air",75,R.drawable.nikemair,"Nike"));
        product.add(new Products("Shoes","Men Boots",80,R.drawable.nikemboots,"Nike"));
        product.add(new Products("Shoes","Women Sneakers",82,R.drawable.pumawsneak,"PUMA"));
        product.add(new Products("Shoes","Women Training",75,R.drawable.awtrain,"Addidas"));
        product.add(new Products("Shoes","Men Sneakers",98,R.drawable.nikemsneak,"Nike"));
        product.add(new Products("Shoes","Men Training",70,R.drawable.pumatrainm,"PUMA"));
        product.add(new Products("Shoes","Women Lifestyle",85,R.drawable.nikewlife,"Nike"));
        product.add(new Products("Shoes","Men Court",79,R.drawable.amcourt,"Addidas"));
        product.add(new Products("Shoes","Men Running",99,R.drawable.amrun,"Addidas"));
        product.add(new Products("Shoes","Women Suede",82,R.drawable.pumasuedew,"PUMA"));
        product.add(new Products("Shoes","Men Sneakers",87,R.drawable.amsneak,"Addidas"));
        product.add(new Products("Shoes","Women GYM",82,R.drawable.pumagymw,"PUMA"));
        product.add(new Products("Shoes","Men Tennis",69,R.drawable.amtennis,"Addidas"));
        product.add(new Products("Shoes","Women TanJun",69,R.drawable.nikewtun,"Nike"));
        product.add(new Products("Shoes","Men Aroma",70,R.drawable.pumaromam,"PUMA"));
        product.add(new Products("Shoes","Women Boots",80,R.drawable.nikwboots,"Nike"));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_continue_shopping);
        sp= findViewById(R.id.spinner);
        lv = findViewById(R.id.lvlist);

        img = findViewById(R.id.imgitem);
        fillData();
        ArrayAdapter aa=new ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,categories);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp.setAdapter(aa);
        sp.setOnItemSelectedListener(this);

        lv.setOnItemSelectedListener(this);
        lv.setOnItemClickListener(this);

    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
            if(adapterView.getId()==R.id.spinner){
                selectedcategory.clear();
                String cat = categories[i];
                for(int j=0;j<product.size();j++)
                    if(product.get(j).getCategory().equals(cat))
                        selectedcategory.add(product.get(j));
                    lv.setAdapter(new ListAdapter(this,selectedcategory));
            }

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        selectedcategoryname = selectedcategory.get(i).getCategory();
        selectedbrands = selectedcategory.get(i).getBrands();
        selectedtype = selectedcategory.get(i).getType();
        selectedprice = (int) selectedcategory.get(i).getPrice();
        selectedimage = selectedcategory.get(i).getImage();

        Intent intent = new Intent(this,DetailsActivity.class);
        startActivity(intent);
    }
}
