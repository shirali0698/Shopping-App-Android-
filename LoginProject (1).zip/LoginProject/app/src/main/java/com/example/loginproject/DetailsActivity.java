package com.example.loginproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class DetailsActivity extends AppCompatActivity implements View.OnClickListener {
    TextView brnd,tpe,prce,cate,total;
    EditText qty;
    ImageView img;
    Button order;
    RadioButton d,p;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        cate = findViewById(R.id.txtcategory);
        brnd = findViewById(R.id.tvbrand);
        tpe = findViewById(R.id.tvtype);
        prce = findViewById(R.id.tvprice);
        total = findViewById(R.id.tvtotal);
        qty = findViewById(R.id.txtquantity);
        img = findViewById(R.id.imgimage);
        order = findViewById(R.id.btnorder);
        d = findViewById(R.id.radioButton);
        p = findViewById(R.id.radioButton2);


        cate.setText(ContinueShopping.selectedcategoryname);
        brnd.setText(ContinueShopping.selectedbrands);
        tpe.setText(ContinueShopping.selectedtype);
       prce.setText(String.valueOf(ContinueShopping.selectedprice));
        img.setImageResource(ContinueShopping.selectedimage);

        order.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        int q=0;
        if(!qty.getText().toString().equals(""))
            q = Integer.parseInt(qty.getText().toString());
        else
            Toast.makeText(getApplicationContext(),"Please enter the quantity",Toast.LENGTH_LONG).show();
        double ttl = Double.parseDouble(prce.getText().toString()) * q;
        if(d.isChecked()  && ttl<50)
            ttl = (ttl *0.10) + ttl;//add 10% to total
        ttl = (ttl *0.13) + ttl;//add 13% to total
        String amount = String.format("%.2f",ttl);
        total.setText(amount);

    }
}
